<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
	#	2co Payment module for Sendroid Ultimate
	#	location: gateway/2checkout/index.php
	#	Developed by: Ynet Interactive
	#	Special thanks: Mr. White

*/
global $LANG;
global $configverssion_id;
global $configapp_version;
global $server;
$userID = getUser();
$resellerID = userData($userID,'reseller');
global $userID;
global $resellerID;

class PaymentGateway {
	function initiatePayment($transaction_reference,$amount,$user_id,$button='') {
		global $LANG;
		$gateway = transactionData($transaction_reference,'method');	//Get the gateway ID from transaction
		$currency = paymentGatewayData($gateway,'currency_id');			//get the currency for this gateway
		$user_currency = userData($user_id,'currency_id');				//The users currency		
		$currency_code = currencyCode($user_currency);					//set user currency code if needed
		$amount_converted = $amount*currencyRate($currency);			//Convert amount to charge to gateway's currency
		if($currency_code==$currency) {
			$amount_converted = $amount;								// No conversion needed
		}
		$stripe_publishable_api_key = trim(paymentGatewayData($gateway,'param1'));	//This is saved in param1 column
		
		//build HTML form

		$out = '<script type="text/javascript" src="https://js.stripe.com/v1/"></script>
        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.2/jquery.min.js"></script>
        <script type="text/javascript">
            Stripe.setPublishableKey(\''.$stripe_publishable_api_key.'\');
            function stripeResponseHandler(status, response) {
                if (response.error) {
                    $(\'#inv_pay_b\').removeAttr("disabled");
					swal("Oops!", response.error.message, "warning");
                } else {
                    var form$ = $("#payment-form");
                    var token = response[\'id\'];
                    form$.append("<input type=\'hidden\' name=\'stripeToken\' value=\'" + token + "\' />");
                    form$.get(0).submit();
                }
            }
            $(document).ready(function() {
                $("#inv_pay_b").click(function(event) {
                    $(\'#inv_pay_b\').attr("disabled", "disabled");
                    Stripe.createToken({
                        number: $(\'.card-number\').val(),
                        cvc: $(\'.card-cvc\').val(),
                        exp_month: $(\'.card-expiry-month\').val(),
                        exp_year: $(\'.card-expiry-year\').val()
                    }, stripeResponseHandler);
                    return false; // submit from callback
                });
            });
        </script>
	<div class="panel-body2">
        <form action="'.home_base_url().'gateway/stripe/callback.php?tx_reference='.$transaction_reference.'" method="POST" id="payment-form" onsubmit="return false;">
        	<table width="90%" border="0" cellspacing="0" cellpadding="0">         
              <tr class="cont">
                <td align="right">
						<div class="row no-m-t no-m-b">
                             <div class="input-field col s12">
                                   <input required id="card-number" size="20" autocomplete="off" type="text" class="validate card-number"  value="">
                                   <label for="card-number">'.$LANG['Card Number'].'</label>
                             </div>
                       	  </div>
						<div class="row no-m-t no-m-b">
                             <div class="input-field col s12">
                                   <input required id="card-cvc" size="4" autocomplete="off" type="text" class="validate card-cvc"  value="">
                                   <label for="card-cvc">'.$LANG['CVC'].'</label>
                             </div>
                       	  </div>
						<div class="row no-m-t no-m-b">
                             <div class="input-field col s6">
                                   <input required id="card-expiry-month" size="2" autocomplete="off" type="number" class="validate card-expiry-month"  value="">
                                   <label for="card-expiry-month">'.$LANG['Expiration (MM)'].'</label>
                             </div>
							 <div class="input-field col s6">
                                   <input required id="card-expiry-year" size="4" autocomplete="off" type="number" class="validate card-expiry-year"  value="">
                                   <label for="card-expiry-year">'.$LANG['Expiration (YYYY)'].'</label>
                             </div>
                       	  </div>
				</td>
              </tr>             
            </table>         
            <input type="hidden" name="transaction_id" value="'.$transaction_reference.'">
            <input type="hidden" name="amount" value="'.round(100*$amount_converted).'">
    </div>';        
		$out .= $button;
		$out .= '</form>';
		return $out;	  
	}
	function validatePayment($transaction_reference,$amount,$user_id,$postdata='') {
		//Not required for strip
	}	
}

?>
